// Brackets
// Exponents
// Division
// Milti
// Addition
// Subtraction
const x = (2 + 8) / ((4 - 2) * (2 ** 2));
